<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\ProductController;
use GuzzleHttp\Middleware;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Auth::routes();

// Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::group(['middleware'=>'auth'],function(){
Route::get('/list',[ProductController::class,'index'])->name('users.list');
Route::get('/user-edit/{id}',[ProductController::class,'useredit'])->name('user.edit');
Route::post('/user-edit/{id}',[ProductController::class,'userupdate'])->name('user.update');
Route::get('/user-delete/{id}',[ProductController::class,'userdelete'])->name('user.delete');
Route::get('/userphone-delete/{id}',[ProductController::class,'userphonedelete'])->name('userphone.delete');
Route::get('/userimage-delete/{id}',[ProductController::class,'userimagedelete'])->name('userimage.delete');
});
