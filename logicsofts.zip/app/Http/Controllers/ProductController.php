<?php

namespace App\Http\Controllers;
use App\Models\Image;
use App\Models\User;
use App\Models\Phone;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    public function construct(){
        $this->middleware('auth');
    }
    public function index(User $user){
        $user = User::with('phones')->with('imag')->get();
        return view('product.index',compact('user'));
    }
    public function useredit($id){
        $phone = Phone::where('user_id',$id)->get();
        $image = Image::where('user_id',$id)->get();
        $user = User::where('id',$id)->with('phones')->with('image')->first();
        return view('product.edit',compact('user'));
    }

    public function userupdate(Request $request,$id){
        $user = User::find($id);
        $user->firstname = $request->firstname;
        $user->lastname = $request->lastname;
        $user->email = $request->email;
        $user->phoneno = $request->phoneno;

        if($contactno1 = $request->phonenos){
            foreach($contactno1 as $contactno)
            {
              if($request->phonermv){
                    $phone = Phone::where('id',$request->phonermv)->update(['user_id'=>$user->id,'contactno'=>$contactno]);
                }
            }
        }

            if($contactnos = $request->contactno){
                foreach($contactnos as $contactno)
                {
                        Phone::create(['user_id'=>$user->id,'contactno'=>$contactno]);
                }
        }
        if ($files = $request->file('image')){
            foreach ($files as  $file){

                {
                    $val = $file->getClientOriginalExtension();
                    if($val == 'jpeg'|| $val == 'jpg'|| $val == 'png'|| $val == 'svg'){
                        $name = time().$file->getClientOriginalName();
                        $file->move('images/',$name);
                        Image::create(['user_id'=>$user->id,'image'=>$name]);

                    }

                }
            }
          }
        $user->update();
        $user->id;
        Session::flash('success', 'Data Updated Successfully.');
        return redirect()->route('user.edit',['id'=>$user->id]);




    }
    public function userdelete($id){
        // $user = DB::table('users')
        // ->join('images','users.id','=','images.user_id')
        // ->join('phones','users.id','=','images.user_id')
        // ->where('users.id',$id)
        // ->select('users.*','phones.*','images.*')
        // ->get();
        // // DB::delete($user);
        //  $user->delete();
        $user = User::find($id);
        $phone = Phone::where('user_id',$user->id)->get();
        $images = Image::where('user_id',$user->id)->get();
          $phone->each->delete();
          $images->each->delete();
            $user->delete();

          return redirect()->back();
          Session::flash('success', 'Data Deleted Successfully.');

    }


    public function userphonedelete(Phone $phone,$id){
        $phone = Phone::find($id);
        $phone->delete();
        return redirect()->back();
        Session::flash('success', 'Data Deleted Successfully.');

    }

    public function userimagedelete($id){
        $image = Image::find($id);
        if (file_exists(public_path().'/images/'.$image->image)) {
            unlink(public_path().'/images/'.$image->image);
          }

        $image->delete();
        return redirect()->back();
        Session::flash('success', 'Data Deleted Successfully.');

    }



}
