<div class="modal fade" id="confirm-delete">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal">
                </button>
            </div>
            <div class="modal-body">
              <p class="text-center">You are about to delete this.</p>
              <p class="text-center">Do you want to proceed?</p>
              </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Close</button>
                <a class="btn btn-primary btn-ok">Delete</a>

                    </div>
        </div>
    </div>
 </div>
