<?php $__env->startSection('content'); ?>

<!--**********************************
    Content body start
***********************************-->
<div class="content-body">
  <div class="container-fluid">
    <div class="row page-titles">
    <ol class="breadcrumb">
    <li class="breadcrumb-item active"><a href="javascript:void(0)">User Listing</a></li>
    </ol>
    </div>
    <?php echo $__env->make('product.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
      <div class="col-12">
        <div class="card">
            <div class="card-header"><h4 class="card-title">User Listing</h4>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table id="example" class="table">
                    <thead>
                    <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Image</th>
                    <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($row->firstname." ".$row->lastname); ?></td>
                        <td><?php echo e($row->email); ?></td>
                        <?php if($row->imag): ?>
                        <td><img src="<?php echo e(asset('images/'.$row->imag->image)); ?>" width="100px" height="100px"><div class="gallery-close">  <i class="fa fa-window-close"></i> </div>
                        </td>
                        <?php else: ?>
                        <td><img src="<?php echo e(asset('images/profile.png')); ?>" width="100px" height="100px"><div class="gallery-close">  <i class="fa fa-window-close"></i> </div>
                        <?php endif; ?>
                        <td>
                          <div class="d-flex">
                            <a href="<?php echo e(route('user.edit',$row->id)); ?>" class="btn btn-primary btn-lg active">Edit</a>
							<a href="#confirm-delete" data-href="<?php echo e(route('user.delete',$row->id)); ?>" data-bs-toggle="modal" data-bs-target="#confirm-delete" class="btn btn-danger btn-lg active">Delete</a>

                          </div>
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
              </div>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php echo $__env->make('product.confirm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--**********************************
    Content body end
***********************************-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">

$('#confirm-delete').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
});

var table = $('#example').DataTable({
		searching: false,
		paging:true,
		select: false,
		info: false,
		lengthChange:false ,
		language: {
			paginate: {
			  previous: "Previous",
			  next: "Next"
			}
		  }

	})
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\spaculus1\resources\views/product/index.blade.php ENDPATH**/ ?>