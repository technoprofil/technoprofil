<?php $__env->startSection('content'); ?>
<div class="content-body">
  <div class="container-fluid">
    <?php echo $__env->make('order.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
      <div class="col-12">
        <div class="card">
            <div class="card-header" style="background-color:white;" ><h1 class="card-title"> <?php if(isset($order)): ?>Edit User <?php else: ?> Add User <?php endif; ?></h1>
            <a href="<?php echo e(route('order.index')); ?>" class="btn btn-primary btn-sm ">Back</a>
            </div>
            <div class="card-body">
              <div class="basic-form custom_file_input">
                <?php if(isset($order)): ?>
                  <form action="<?php echo e(route('order.update',$order->id)); ?>" method="POST" enctype="multipart/form-data">
                  <?php echo method_field('put'); ?>
                  <?php else: ?>
                  <form action="<?php echo e(route('order.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php endif; ?>
                
                  <?php echo csrf_field(); ?>
                  <div class="form-group row">
                            <div class="form-group col-12 col-sm-6 <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
                                <label for="title">Title</label>
                                <input id="title" <?php if(isset($order)): ?>  value= "<?php echo e($order->title); ?>" <?php endif; ?> class="form-control form-control-sm" type="text" name="title" placeholder="Title">
                                <?php if($errors->has('title')): ?>
                                    <em class="invalid-feedback">
                                        <?php echo e($errors->first('title')); ?>

                                    </em>
                                <?php endif; ?>
                              </div>
                            <div class="form-group col-12 col-sm-6 <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                                <label for="description">Description</label>
                                <textarea class="form-control" name="description" cols="20" rows="5" id="description"><?php if(isset($order)): ?> <?php echo e($order->description); ?> <?php endif; ?></textarea>
                                <?php if($errors->has('description')): ?>
                                    <em class="invalid-feedback">
                                        <?php echo e($errors->first('description')); ?>

                                    </em>
                                <?php endif; ?>
                            </div>
                            <?php if(isset($order)): ?>
                            <div class="form-group col-12 col-sm-6">
                            <img src="<?php echo e(asset('images/'.$order->image)); ?>" width="100px" height="100px">
                            </div>
                            <?php endif; ?>
                            <div class="form-group col-12 col-sm-6 <?php echo e($errors->has('image') ? 'has-error' : ''); ?>">
                                <label for="image">Upload Image</label>
                                <input id="image" value="" class="form-control form-control-sm" type="file" name="image" >
                                <?php if($errors->has('image')): ?>
                                    <em class="invalid-feedback">
                                        <?php echo e($errors->first('image')); ?>

                                    </em>
                                <?php endif; ?>
                              </div>
                                <div class="col-12 mt-3">
                                <button type="submit" class="btn btn-primary mb-2">Submit</button>
                            </div>
                  </div>
                </form>
              </div>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php echo $__env->make('order.confirm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\mmbo\resources\views/order/edit.blade.php ENDPATH**/ ?>