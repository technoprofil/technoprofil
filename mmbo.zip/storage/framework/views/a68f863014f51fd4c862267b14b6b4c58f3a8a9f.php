

<?php $__env->startSection('content'); ?>
<div class="content-body">
  <div class="container-fluid">
    <?php echo $__env->make('product.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
      <div class="col-12">
        <div class="card">
            <div class="card-header" style="background-color:white;" ><h1 class="card-title">Edit User</h1>
            <a href="<?php echo e(route('users.list')); ?>" class="btn btn-primary btn-sm ">Back</a>
            </div>
            <div class="card-body">
              <div class="basic-form custom_file_input">
                <form action="<?php echo e(route('user.update',$user->id)); ?>" method="post" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <div class="form-group row">
                            <div class="mb-3">
                                <label for="title">First Name</label>
                                <input id="title" value="<?php echo e($user->firstname); ?>" class="form-control form-control-sm" type="text" name="firstname" placeholder="First Name">
                            </div>
                            <div class="mb-3">
                                <label for="title">Last Name</label>
                                <input id="title" value="<?php echo e($user->lastname); ?>" class="form-control form-control-sm" type="text" name="lastname" placeholder="Last Name">
                            </div>
                            <div class="mb-3">
                                <label for="title">Your Email</label>
                                <input id="title" value="<?php echo e($user->email); ?>" class="form-control form-control-sm" type="text" name="email" placeholder="Email">
                            </div>
                            <div class="mb-3">
                                 <label for="title">Phone No</label>
                                 <input id="title" value="<?php echo e($user->phoneno); ?>" class="form-control form-control-sm" type="number" name="phoneno" placeholder="Phone Number">
                                 <button id="phone" class="btn btn-primary">+</button>
                                 <div id="phoneno"></div>
                                 <?php if($user['phones']): ?>
                                 <?php $__currentLoopData = $user['phones']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <label for="title">Phone No</label>
                                 <input id="title" value="<?php echo e($phone->contactno); ?>" class="form-control form-control-sm" type="number" name="phonenos[]" placeholder="Phone Number">
                                 <input id="phonermv" name="phonermv"  type="hidden" value="<?php echo e($phone->id); ?>">
                                 <a href="#confirm-delete" data-href="<?php echo e(route('userphone.delete',$phone->id)); ?>" data-bs-toggle="modal" data-bs-target="#confirm-delete" class="btn btn-danger shadow btn-xs sharp">-</a>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 <?php endif; ?>

                             </div>

                            <div class="mb-3">
                                <label for="title">Upload Image</label>
                                <input id="title" value="" class="form-control form-control-sm" type="file" name="image[]" >
                                    <button id="image" class="btn btn-primary">+</button>
                                    <div id="allimage"></div>
                            </div>
                            <div class="row">
                                 <?php if($user['image']): ?>
                                    <?php $__currentLoopData = $user['image']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="column">
                                        <img src="<?php echo e(asset('images/'.$images->image)); ?>" width="100px" height="100px"><div class="gallery-close"> </div>
                                        <input id="imageclose" name="imageclose" type="hidden" value="<?php echo e($images->id); ?>">
                                        <a href="#confirm-delete" data-href="<?php echo e(route('userimage.delete',$images->id)); ?>" data-bs-toggle="modal" data-bs-target="#confirm-delete" class="btn btn-danger shadow btn-xs sharp">-</a>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                            </div>
                                <div class="col-12 mt-3">
                                <button type="submit" class="btn btn-primary mb-2">Submit</button>
                            </div>
                  </div>
                </form>
              </div>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php echo $__env->make('product.confirm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    //append input
    $(document).ready(function(){
  $("#phone").click(function(e) {
    e.preventDefault();
    $("#phoneno").append("<div class='mb-3'><div id='inputFormRow'><label for='phoneno'>Phone No</label><input id='remove' type='text' class='form-control form-control-sm' name='contactno[]' placeholder='Phone Number' /><button id='phoneremov' class='btn btn-danger'>-</button></div> </div>");
  });
});

$(document).ready(function(){
  $("#image").click(function(e) {
    e.preventDefault();
    $("#allimage").append("<div class='mb-3'><div id='imageremoveRow'> <label for='image'>Upload Image</label><input type='file' class='form-control form-control-sm' name='image[]' /><button id='imageremove' class='btn btn-danger'>-</button> </div> </div>");
  });
});

//blank phone input remove
$(document).on('click', '#phoneremov', function () {
        $(this).closest('#inputFormRow').remove();
    });

    $(document).on('click', '#imageremove', function () {
        $(this).closest('#imageremoveRow').remove();
    });

//remove image phone from databsase

$('#confirm-delete').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
});

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\mmbo\resources\views/order/create.blade.php ENDPATH**/ ?>