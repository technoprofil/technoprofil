@extends('layouts.app')

@section('content')
<div class="content-body">
  <div class="container-fluid">
    @include('product.form-success')
    <div class="row">
      <div class="col-12">
        <div class="card">
            <div class="card-header" style="background-color:white;" ><h1 class="card-title">Edit User</h1>
            <a href="{{route('users.list')}}" class="btn btn-primary btn-sm ">Back</a>
            </div>
            <div class="card-body">
              <div class="basic-form custom_file_input">
                <form action="{{route('user.update',$user->id)}}" method="post" enctype="multipart/form-data">
                  @csrf
                  <div class="form-group row">
                            <div class="mb-3">
                                <label for="title">First Name</label>
                                <input id="title" value="{{ $user->firstname }}" class="form-control form-control-sm" type="text" name="firstname" placeholder="First Name">
                            </div>
                            <div class="mb-3">
                                <label for="title">Last Name</label>
                                <input id="title" value="{{ $user->lastname }}" class="form-control form-control-sm" type="text" name="lastname" placeholder="Last Name">
                            </div>
                            <div class="mb-3">
                                <label for="title">Your Email</label>
                                <input id="title" value="{{ $user->email }}" class="form-control form-control-sm" type="text" name="email" placeholder="Email">
                            </div>
                            <div class="mb-3">
                                 <label for="title">Phone No</label>
                                 <input id="title" value="{{ $user->phoneno }}" class="form-control form-control-sm" type="number" name="phoneno" placeholder="Phone Number">
                                 <button id="phone" class="btn btn-primary">+</button>
                                 <div id="phoneno"></div>
                                 @if($user['phones'])
                                 @foreach($user['phones'] as $phone)
                                 <label for="title">Phone No</label>
                                 <input id="title" value="{{ $phone->contactno }}" class="form-control form-control-sm" type="number" name="phonenos[]" placeholder="Phone Number">
                                 <input id="phonermv" name="phonermv"  type="hidden" value="{{ $phone->id}}">
                                 <a href="#confirm-delete" data-href="{{route('userphone.delete',$phone->id)}}" data-bs-toggle="modal" data-bs-target="#confirm-delete" class="btn btn-danger shadow btn-xs sharp">-</a>
                                 @endforeach
                                 @endif

                             </div>

                            <div class="mb-3">
                                <label for="title">Upload Image</label>
                                <input id="title" value="" class="form-control form-control-sm" type="file" name="image[]" >
                                    <button id="image" class="btn btn-primary">+</button>
                                    <div id="allimage"></div>
                            </div>
                            <div class="row">
                                 @if($user['image'])
                                    @foreach($user['image'] as $images)
                                    <div class="column">
                                        <img src="{{asset('images/'.$images->image)}}" width="100px" height="100px"><div class="gallery-close"> </div>
                                        <input id="imageclose" name="imageclose" type="hidden" value="{{ $images->id }}">
                                        <a href="#confirm-delete" data-href="{{route('userimage.delete',$images->id)}}" data-bs-toggle="modal" data-bs-target="#confirm-delete" class="btn btn-danger shadow btn-xs sharp">-</a>
                                    </div>
                                    @endforeach
                                    @endif
                            </div>
                                <div class="col-12 mt-3">
                                <button type="submit" class="btn btn-primary mb-2">Submit</button>
                            </div>
                  </div>
                </form>
              </div>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>
@include('product.confirm')

@endsection
@section('scripts')
<script>
    //append input
    $(document).ready(function(){
  $("#phone").click(function(e) {
    e.preventDefault();
    $("#phoneno").append("<div class='mb-3'><div id='inputFormRow'><label for='phoneno'>Phone No</label><input id='remove' type='text' class='form-control form-control-sm' name='contactno[]' placeholder='Phone Number' /><button id='phoneremov' class='btn btn-danger'>-</button></div> </div>");
  });
});

$(document).ready(function(){
  $("#image").click(function(e) {
    e.preventDefault();
    $("#allimage").append("<div class='mb-3'><div id='imageremoveRow'> <label for='image'>Upload Image</label><input type='file' class='form-control form-control-sm' name='image[]' /><button id='imageremove' class='btn btn-danger'>-</button> </div> </div>");
  });
});

//blank phone input remove
$(document).on('click', '#phoneremov', function () {
        $(this).closest('#inputFormRow').remove();
    });

    $(document).on('click', '#imageremove', function () {
        $(this).closest('#imageremoveRow').remove();
    });

//remove image phone from databsase

$('#confirm-delete').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
});

    </script>
@endsection
