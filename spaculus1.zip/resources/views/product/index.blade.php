@extends('layouts.app')

@section('content')

<!--**********************************
    Content body start
***********************************-->
<div class="content-body">
  <div class="container-fluid">
    <div class="row page-titles">
    <ol class="breadcrumb">
    <li class="breadcrumb-item active"><a href="javascript:void(0)">User Listing</a></li>
    </ol>
    </div>
    @include('product.form-success')
    <div class="row">
      <div class="col-12">
        <div class="card">
            <div class="card-header"><h4 class="card-title">User Listing</h4>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table id="example" class="table">
                    <thead>
                    <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Image</th>
                    <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                      @foreach($user as $row)
                      <tr>
                        <td>{{$row->firstname." ".$row->lastname}}</td>
                        <td>{{$row->email}}</td>
                        @if($row->imag)
                        <td><img src="{{asset('images/'.$row->imag->image)}}" width="100px" height="100px"><div class="gallery-close">  <i class="fa fa-window-close"></i> </div>
                        </td>
                        @else
                        <td><img src="{{asset('images/profile.png')}}" width="100px" height="100px"><div class="gallery-close">  <i class="fa fa-window-close"></i> </div>
                        @endif
                        <td>
                          <div class="d-flex">
                            <a href="{{route('user.edit',$row->id)}}" class="btn btn-primary btn-lg active">Edit</a>
							<a href="#confirm-delete" data-href="{{route('user.delete',$row->id)}}" data-bs-toggle="modal" data-bs-target="#confirm-delete" class="btn btn-danger btn-lg active">Delete</a>

                          </div>
                        </td>
                      </tr>
                      @endforeach
                    </tbody>
                </table>
              </div>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>

@include('product.confirm')

<!--**********************************
    Content body end
***********************************-->
@endsection

@section('scripts')
<script type="text/javascript">

$('#confirm-delete').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
});

var table = $('#example').DataTable({
		searching: false,
		paging:true,
		select: false,
		info: false,
		lengthChange:false ,
		language: {
			paginate: {
			  previous: "Previous",
			  next: "Next"
			}
		  }

	})
</script>
@endsection
